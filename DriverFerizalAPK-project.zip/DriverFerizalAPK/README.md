# Driver Ferizal Android app project

Aplikasi HTML lokal dibungkus WebView Android. Data disimpan lokal di WebView (`localStorage`), tanpa koneksi internet yang diperlukan.

## Build APK
1. Install Android Studio (versi terbaru yang mendukung Android Gradle Plugin 8.6.1).
2. Buka folder `DriverFerizalAPK` sebagai project.
3. Tunggu Gradle Sync, install Android SDK Platform 35 jika diminta.
4. Pilih **Build > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur native yang ditambahkan
- Ikon launcher memakai logo yang diberikan.
- Ekspor CSV dan JSON diarahkan ke Download/DriverFerizal.
- Pemilih file untuk restore backup JSON.
- WebView local storage dipertahankan selama aplikasi tidak dihapus/reset.

## Catatan
Ini project sumber untuk build APK. APK belum dikompilasi di lingkungan ini karena Android SDK/Gradle build tools tidak tersedia.
